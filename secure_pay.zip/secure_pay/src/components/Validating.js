import React from 'react'

const Validating = () => {
  return (
    <div>Validating</div>
  )
}

export default Validating