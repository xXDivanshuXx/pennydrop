import React from 'react'
import Cards from '../compound/Cards'
import Header from '../compound/Header'
import Titled from '../compound/Titled'

const Homee = () => {

  return (
  <>
  <Header/>
  </>
    )
}

export default Homee